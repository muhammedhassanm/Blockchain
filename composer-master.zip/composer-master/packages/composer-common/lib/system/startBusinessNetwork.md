*StartBusinessNetwork* is a system transaction that starts a business network. Both the *logLevel* and *bootstrapTransactions* properties are optional.

```
transaction StartBusinessNetwork {
  o String logLevel optional
  o Transaction[] bootstrapTransactions optional
}
```
