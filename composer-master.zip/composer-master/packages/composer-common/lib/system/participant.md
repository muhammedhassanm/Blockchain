The base *participant* is implicitly extended by all other participants. *Participant* is an **abstract** meaning that no instances of it can be created.

```
abstract participant Participant {   }
```
