*Network* is a system asset, containing the *networkId* and *runtimeVersion* properties.

```
asset Network identified by networkId {
  o String networkId
  o String runtimeVersion
}
```
