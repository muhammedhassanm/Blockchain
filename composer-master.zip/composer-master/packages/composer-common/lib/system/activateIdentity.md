*ActivateCurrentIdentity** is a system transaction which activates the identity currently being used.

```
transaction ActivateCurrentIdentity { }
```
