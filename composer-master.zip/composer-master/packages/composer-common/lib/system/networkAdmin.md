*NetworkAdmin* is a system participant type used as an initial user in a network. *NetworkAdmin* extends *participant* and has the *participantId* property.

```
participant NetworkAdmin identified by participantId {
    o String participantId
}
```
