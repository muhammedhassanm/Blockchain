*RevokeIdentity* is a system transaction which revokes a specified identity.

```
transaction RevokeIdentity {
    --> Identity identity
}
```
