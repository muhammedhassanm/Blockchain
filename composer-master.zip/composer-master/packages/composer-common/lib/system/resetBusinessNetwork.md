*ResetBusinessNetwork* is a system transaction which deletes all data in a business network, while leaving the business network definition intact.

```
transaction ResetBusinessNetwork {

}
```
