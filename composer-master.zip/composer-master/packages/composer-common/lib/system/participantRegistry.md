*ParticipantRegistry* is not an **abstract** so instances of it can be created. *ParticipantRegistry* extends the Registry type. As an extension of Registry, it includes the properties of Registry.

```
asset ParticipantRegistry extends Registry { }
```
