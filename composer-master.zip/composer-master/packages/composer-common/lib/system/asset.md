The base *asset* is implicitly extended by all other assets. *Asset* is an **abstract** meaning that no instances of it can be created.

```
abstract asset Asset {  }
```
