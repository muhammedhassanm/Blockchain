*TransactionRegistry* is not an **abstract** so instances of it can be created. *TransactionRegistry* extends the Registry type. As an extension of Registry, it includes the properties of Registry.

```
asset TransactionRegistry extends Registry { }
```
