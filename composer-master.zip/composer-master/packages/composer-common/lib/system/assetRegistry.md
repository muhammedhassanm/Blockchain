*AssetRegistry* is not an **abstract** so instances of it can be created. *AssetRegistry* extends the Registry type. As an extension of Registry, it includes the properties of Registry.

```
asset AssetRegistry extends Registry { }
```
