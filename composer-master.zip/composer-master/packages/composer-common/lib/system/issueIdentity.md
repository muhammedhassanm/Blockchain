*IssueIdentity* is a system transaction which issues an identity to a participant. 

```
transaction IssueIdentity {
    --> Participant participant
    o String identityName
}
```
