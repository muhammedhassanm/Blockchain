composer card import --file ./fabric/id-cards/grower-network-admin.card
composer card import --file ./fabric/id-cards/producer-network-admin.card
composer card import --file ./fabric/id-cards/filler-network-admin.card
composer card import --file ./fabric/id-cards/distributor-network-admin.card
composer card import --file ./fabric/id-cards/retailer-network-admin.card

composer card import --file ./fabric/id-cards/PeerAdmin@biswas-grower.card
composer card import --file ./fabric/id-cards/PeerAdmin@biswas-producer.card
composer card import --file ./fabric/id-cards/PeerAdmin@biswas-filler.card
composer card import --file ./fabric/id-cards/PeerAdmin@biswas-distributor.card
composer card import --file ./fabric/id-cards/PeerAdmin@biswas-retailer.card
