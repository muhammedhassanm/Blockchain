docker-compose -f ./fabric/docker/docker-compose-sdk.yaml down
