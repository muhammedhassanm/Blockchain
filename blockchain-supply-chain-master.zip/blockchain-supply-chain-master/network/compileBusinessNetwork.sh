composer archive create --sourceType dir --sourceName ./composer --archiveFile ./composer/biswas.bna
