docker-compose -f docker/docker-compose-sdk.yaml down
