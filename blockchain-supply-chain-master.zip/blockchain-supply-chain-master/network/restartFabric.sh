docker-compose -f ./fabric/docker/docker-compose-sdk.yaml down
docker-compose -f ./fabric/docker/docker-compose-sdk.yaml up -d
