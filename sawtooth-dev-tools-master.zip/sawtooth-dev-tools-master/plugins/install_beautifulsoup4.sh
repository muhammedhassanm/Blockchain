#!/bin/bash -x

set -e

pip install beautifulsoup4
