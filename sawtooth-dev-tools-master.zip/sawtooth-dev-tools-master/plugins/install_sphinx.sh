#!/bin/bash -x

set -e

pip install sphinx
pip install sphinx_rtd_theme
pip install sphinxcontrib-httpdomain

