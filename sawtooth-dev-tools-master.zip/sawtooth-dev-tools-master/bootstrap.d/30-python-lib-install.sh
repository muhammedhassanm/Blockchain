#!/bin/bash -x

set -e

pip install cbor
pip install pybitcointools
pip install colorlog
pip install coverage
pip install nose2
pip install cov-core
pip install pylint
pip install setuptools-lint
pip install pep8
pip install networkx
pip install daemonize
pip install psutil
pip install demjson
