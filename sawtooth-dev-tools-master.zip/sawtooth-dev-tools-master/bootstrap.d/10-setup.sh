#!/bin/bash -x

mkdir -p cache || exit 1

