#!/bin/bash -x



export PATH=$PATH:/project/sawtooth-validator/bin
